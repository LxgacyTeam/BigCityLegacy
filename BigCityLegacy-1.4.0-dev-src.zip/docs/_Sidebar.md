# 📚 Документация на Русском

## 🚀 Начало работы
- [Описание](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9A%80-%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BE-%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%8B)
- [Функции и возможности](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9A%80-%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BE-%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%8B#%D1%84%D1%83%D0%BD%D0%BA%D1%86%D0%B8%D0%B8-%D0%B8-%D0%B2%D0%BE%D0%B7%D0%BC%D0%BE%D0%B6%D0%BD%D0%BE%D1%81%D1%82%D0%B8-%D0%BF%D0%BE%D0%B4%D1%80%D0%BE%D0%B1%D0%BD%D0%BE)
- [Параметры запуска](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9A%80-%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BE-%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%8B#%D0%BF%D0%B0%D1%80%D0%B0%D0%BC%D0%B5%D1%82%D1%80%D1%8B-%D0%B7%D0%B0%D0%BF%D1%83%D1%81%D0%BA%D0%B0)
  - [Для клиента](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9A%80-%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BE-%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%8B#%D0%B4%D0%BB%D1%8F-%D0%BA%D0%BB%D0%B8%D0%B5%D0%BD%D1%82%D0%B0)
  - [Для сервера](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9A%80-%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BE-%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%8B#%D0%B4%D0%BB%D1%8F-%D1%81%D0%B5%D1%80%D0%B2%D0%B5%D1%80%D0%B0)
- [Режим совместимости](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9A%80-%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BE-%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%8B#%D1%80%D0%B5%D0%B6%D0%B8%D0%BC-%D1%81%D0%BE%D0%B2%D0%BC%D0%B5%D1%81%D1%82%D0%B8%D0%BC%D0%BE%D1%81%D1%82%D0%B8)
- [Подключение к серверу](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9A%80-%D0%9D%D0%B0%D1%87%D0%B0%D0%BB%D0%BE-%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%8B#%D0%BF%D0%BE%D0%B4%D0%BA%D0%BB%D1%8E%D1%87%D0%B5%D0%BD%D0%B8%D0%B5-%D0%BA-%D1%81%D0%B5%D1%80%D0%B2%D0%B5%D1%80%D1%83)

## 🛜 Сервер
- [Архитектура](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%9C-%D0%A1%D0%B5%D1%80%D0%B2%D0%B5%D1%80#%D1%81%D0%B5%D1%80%D0%B2%D0%B5%D1%80)
  - [Game Server](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%9C-%D0%A1%D0%B5%D1%80%D0%B2%D0%B5%D1%80#game-server)
  - [Mirror Server](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%9C-%D0%A1%D0%B5%D1%80%D0%B2%D0%B5%D1%80#mirror-%D1%81%D0%B5%D1%80%D0%B2%D0%B5%D1%80)
- [Администрирование и CLI интерфейс](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%9C-%D0%A1%D0%B5%D1%80%D0%B2%D0%B5%D1%80#%D0%B0%D0%B4%D0%BC%D0%B8%D0%BD%D0%B8%D1%81%D1%82%D1%80%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5-%D0%B8-cli-%D0%B8%D0%BD%D1%82%D0%B5%D1%80%D1%84%D0%B5%D0%B9%D1%81)
  - [PlayerID](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%9C-%D0%A1%D0%B5%D1%80%D0%B2%D0%B5%D1%80#playerid)
  - [Система банов](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%9C-%D0%A1%D0%B5%D1%80%D0%B2%D0%B5%D1%80#%D1%81%D0%B8%D1%81%D1%82%D0%B5%D0%BC%D0%B0-%D0%B1%D0%B0%D0%BD%D0%BE%D0%B2)

## 🧩 Онлайн Ивенты
- [Описание и архитектура](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%A7%A9-%D0%9E%D0%BD%D0%BB%D0%B0%D0%B9%D0%BD-%D0%98%D0%B2%D0%B5%D0%BD%D1%82%D1%8B#%D0%BE%D0%BD%D0%BB%D0%B0%D0%B9%D0%BD-%D0%B8%D0%B2%D0%B5%D0%BD%D1%82%D1%8B)
- [Онлайн-гонки: создание трасс](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%A7%A9-%D0%9E%D0%BD%D0%BB%D0%B0%D0%B9%D0%BD-%D0%98%D0%B2%D0%B5%D0%BD%D1%82%D1%8B#%D0%BE%D0%BD%D0%BB%D0%B0%D0%B9%D0%BD-%D0%B3%D0%BE%D0%BD%D0%BA%D0%B8-%D1%81%D0%BE%D0%B7%D0%B4%D0%B0%D0%BD%D0%B8%D0%B5-%D1%82%D1%80%D0%B0%D1%81%D1%81)
- [Копы против Бандитов: создание локаций](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%A7%A9-%D0%9E%D0%BD%D0%BB%D0%B0%D0%B9%D0%BD-%D0%98%D0%B2%D0%B5%D0%BD%D1%82%D1%8B#%D0%BA%D0%BE%D0%BF%D1%8B-%D0%BF%D1%80%D0%BE%D1%82%D0%B8%D0%B2-%D0%B1%D0%B0%D0%BD%D0%B4%D0%B8%D1%82%D0%BE%D0%B2-%D1%81%D0%BE%D0%B7%D0%B4%D0%B0%D0%BD%D0%B8%D0%B5-%D0%BB%D0%BE%D0%BA%D0%B0%D1%86%D0%B8%D0%B9)
- [Point Tool v2](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%A7%A9-%D0%9E%D0%BD%D0%BB%D0%B0%D0%B9%D0%BD-%D0%98%D0%B2%D0%B5%D0%BD%D1%82%D1%8B#%D0%B8%D0%BD%D1%81%D1%82%D1%80%D1%83%D0%BC%D0%B5%D0%BD%D1%82-point-tool-v2)

## 🛠 Для разработчиков
- [LegacyUIFramework](https://github.com/LxgacyTeam/LegacyUIFramework/blob/main/docs/README_RU.md)
- [Хелперы](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%A0-%D0%94%D0%BB%D1%8F-%D1%80%D0%B0%D0%B7%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%87%D0%B8%D0%BA%D0%BE%D0%B2:-%D0%A5%D0%B5%D0%BB%D0%BF%D0%B5%D1%80%D1%8B)
  - [LegacyHelpers](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%A0-%D0%94%D0%BB%D1%8F-%D1%80%D0%B0%D0%B7%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%87%D0%B8%D0%BA%D0%BE%D0%B2:-%D0%A5%D0%B5%D0%BB%D0%BF%D0%B5%D1%80%D1%8B#legacyhelpers)
  - [LegacyCommandLine.HasArg](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%A0-%D0%94%D0%BB%D1%8F-%D1%80%D0%B0%D0%B7%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%87%D0%B8%D0%BA%D0%BE%D0%B2:-%D0%A5%D0%B5%D0%BB%D0%BF%D0%B5%D1%80%D1%8B#legacycommandlinehasargstring-arg)
  - [NativeErrorDialog](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%A0-%D0%94%D0%BB%D1%8F-%D1%80%D0%B0%D0%B7%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%87%D0%B8%D0%BA%D0%BE%D0%B2:-%D0%A5%D0%B5%D0%BB%D0%BF%D0%B5%D1%80%D1%8B#nativeerrordialog)
- [LegacyLocalizer](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%A0-%D0%94%D0%BB%D1%8F-%D1%80%D0%B0%D0%B7%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%87%D0%B8%D0%BA%D0%BE%D0%B2:-LegacyLocalizer)
- [LegacyPatchManager](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%A0-%D0%94%D0%BB%D1%8F-%D1%80%D0%B0%D0%B7%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%87%D0%B8%D0%BA%D0%BE%D0%B2:-LegacyPatchManager)
- [LegacySettingsMenuHelper](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%A0-%D0%94%D0%BB%D1%8F-%D1%80%D0%B0%D0%B7%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D1%87%D0%B8%D0%BA%D0%BE%D0%B2:-LegacySettingsMenuHelper)


---


# 📚 Documentation on English

## 🚀 Getting Started
- [Overview](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9A%80-Getting-Started)
- [Features and capabilities](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9A%80-Getting-Started#features-and-capabilities-in-detail)
- [Launch arguments](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9A%80-Getting-Started#launch-arguments)
  - [Client arguments](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9A%80-Getting-Started#client-arguments)
  - [Server arguments](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9A%80-Getting-Started#server-arguments)
- [Compatibility Mode](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9A%80-Getting-Started#compatibility-mode)
- [Connecting to a server](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9A%80-Getting-Started#connecting-to-a-server)

## 🛜 Server
- [Architecture](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%9C-Server)
  - [Game Server](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%9C-Server#game-server)
  - [Mirror Server](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%9C-Server#mirror-server)
- [Administration and CLI interface](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%9C-Server#administration-and-cli-interface)
  - [PlayerID](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%9C-Server#playerid)
  - [Ban system](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%9C-Server#ban-system)

## 🧩 Online Events
- [Overview and architecture](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%A7%A9-Online-Events)
- [Online races: creating tracks](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%A7%A9-Online-Events#online-races-creating-tracks)
- [Cops vs Bandits: creating locations](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%A7%A9-Online-Events#cops-vs-bandits-creating-locations)
- [Point Tool v2](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%A7%A9-Online-Events#point-tool-v2)

## 🛠 For developers
- [LegacyUIFramework](https://github.com/[LxgacyTeam/LegacyUIFramework](https://github.com/LxgacyTeam/LegacyUIFramework))
- [Helpers]()
  - [LegacyHelpers](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%A0-For-developers:-Helpers)
  - [LegacyCommandLine.HasArg](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%A0-For-developers:-Helpers#legacycommandlinehasargstring-arg)
  - [NativeErrorDialog](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%A0-For-developers:-Helpers#nativeerrordialog)
- [LegacyLocalizer](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%A0-For-developers:-LegacyLocalizer)
- [LegacyPatchManager](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%A0-For-developers:-LegacyPatchManager)
- [LegacySettingsMenuHelper](https://github.com/LxgacyTeam/BigCityLegacy/wiki/%F0%9F%9B%A0-For-developers:-LegacySettingsMenuHelper)
