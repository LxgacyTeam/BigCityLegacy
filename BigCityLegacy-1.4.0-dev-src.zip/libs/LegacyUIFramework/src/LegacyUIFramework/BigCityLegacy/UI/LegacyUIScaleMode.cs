namespace BigCityLegacy.UI
{
    /// <summary>How a LegacyUIGuiScope chooses its initial scale.</summary>
    public enum LegacyUIScaleMode
    {
        Automatic,
        Manual
    }
}
